
import 'package:flutter/material.dart';
import 'package:item_look_up/ChatAssistStateFulHomePage.dart';

 class ChatAssistHomePage extends StatefulWidget {
  ChatAssistHomePage({Key key, this.title}) : super(key: key);
  final String title;
  @override
  ChatAssistStateFulHomePage createState() => new ChatAssistStateFulHomePage();
}

